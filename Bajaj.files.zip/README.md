# BFHL Node Hierarchy Explorer
SRM Full Stack Engineering Challenge — Round 1

## 📁 Project Structure
```
bfhl-app/
├── server.js       ← Express REST API  (POST /bfhl)
├── index.html      ← Single-page frontend
├── package.json
└── README.md
```

---

## ⚡ Quick Start (local)

```bash
npm install
npm start          # API runs on http://localhost:3001
```

Open `index.html` in your browser (no build step needed).
Set the API URL field to `http://localhost:3001/bfhl` and click **Analyse**.

---

## 🔧 Before You Submit — REQUIRED Changes

Edit the top of `server.js`:

```js
const USER_ID  = "yourname_ddmmyyyy";       // e.g. "johndoe_17091999"
const EMAIL_ID = "your.email@college.edu";
const ROLL     = "ROLLNUMBER";               // e.g. "21CS1001"
```

---

## 🚀 Deployment

### Backend → Render (free)
1. Push this repo to GitHub.
2. Go to [render.com](https://render.com) → **New Web Service** → connect repo.
3. Build command: `npm install`
4. Start command: `node server.js`
5. Note your URL: `https://bfhl-xxx.onrender.com`

### Frontend → Netlify (free)
1. Go to [netlify.com](https://netlify.com) → **Add new site** → drag-drop the folder  
   OR connect your GitHub repo (set publish directory to `/`).
2. Before deploying, edit `index.html` line with `value="http://localhost:3001/bfhl"`  
   → change to your Render backend URL.

---

## 📡 API Reference

### `POST /bfhl`
```json
{ "data": ["A->B", "A->C", "B->D", "hello", "1->2"] }
```

**Valid edge format:** `X->Y` where X and Y are single uppercase letters (A–Z), X ≠ Y.

**Response fields:**
| Field | Description |
|---|---|
| `user_id` | `fullname_ddmmyyyy` |
| `email_id` | College email |
| `college_roll_number` | Your roll number |
| `hierarchies` | Array of hierarchy objects |
| `invalid_entries` | Entries that failed validation |
| `duplicate_edges` | Repeated edges (first occurrence used) |
| `summary` | `total_trees`, `total_cycles`, `largest_tree_root` |

---

## ✅ Evaluation Checklist
- [x] POST /bfhl endpoint
- [x] CORS enabled
- [x] Valid node format validation (single uppercase letters only)
- [x] Self-loop detection (A->A → invalid)
- [x] Whitespace trimming
- [x] Duplicate edge detection
- [x] Multi-parent rule (first-seen parent wins)
- [x] Cycle detection (DFS-based)
- [x] Pure-cycle groups use lex-smallest node as root
- [x] Depth calculation (node count on longest path)
- [x] Summary with tiebreaker (lex-smaller root wins)
- [x] Frontend with tree view, tags, raw JSON
- [x] Error handling on API failure
- [x] Ctrl+Enter shortcut to submit
