const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

// ── Identity ──────────────────────────────────────────────────────────────────
const USER_ID = "yourname_ddmmyyyy";       // ← CHANGE THIS
const EMAIL_ID = "your.email@college.edu"; // ← CHANGE THIS
const ROLL = "ROLLNUMBER";                  // ← CHANGE THIS

// ── Helpers ───────────────────────────────────────────────────────────────────

/** Validate and parse an edge string. Returns {parent, child} or null. */
function parseEdge(raw) {
  const entry = raw.trim();
  // Must match exactly X->Y  where X,Y are single uppercase letters
  if (!/^[A-Z]->[A-Z]$/.test(entry)) return null;
  const [parent, child] = entry.split("->");
  if (parent === child) return null; // self-loop → invalid
  return { parent, child };
}

/** Build adjacency list and find connected components via Union-Find. */
function buildUnionFind(edges) {
  const parent = {};
  function find(x) {
    if (!(x in parent)) parent[x] = x;
    if (parent[x] !== x) parent[x] = find(parent[x]);
    return parent[x];
  }
  function union(a, b) {
    parent[find(a)] = find(b);
  }
  edges.forEach(({ parent: p, child: c }) => union(p, c));
  return find;
}

/** Detect cycle in a directed graph using DFS. */
function hasCycle(nodes, adjList) {
  const WHITE = 0, GRAY = 1, BLACK = 2;
  const color = {};
  nodes.forEach((n) => (color[n] = WHITE));

  function dfs(u) {
    color[u] = GRAY;
    for (const v of adjList[u] || []) {
      if (color[v] === GRAY) return true;
      if (color[v] === WHITE && dfs(v)) return true;
    }
    color[u] = BLACK;
    return false;
  }

  for (const n of nodes) {
    if (color[n] === WHITE && dfs(n)) return true;
  }
  return false;
}

/** Build nested tree object starting from `node`. */
function buildTree(node, adjList, visited = new Set()) {
  if (visited.has(node)) return {};
  visited.add(node);
  const children = {};
  for (const child of adjList[node] || []) {
    children[child] = buildTree(child, adjList, visited);
  }
  return children;
}

/** Depth = number of nodes on the longest root-to-leaf path. */
function calcDepth(node, treeObj) {
  const children = Object.keys(treeObj[node] || treeObj || {});
  // treeObj here is the subtree rooted at node
  const subtree = treeObj[node] !== undefined ? treeObj[node] : treeObj;
  const childKeys = Object.keys(subtree);
  if (childKeys.length === 0) return 1;
  return 1 + Math.max(...childKeys.map((c) => calcDepth(c, subtree[c] !== undefined ? { [c]: subtree[c] } : {})));
}

/** Recursive depth on nested tree structure. */
function treeDepth(node, adjList) {
  const children = adjList[node] || [];
  if (children.length === 0) return 1;
  return 1 + Math.max(...children.map((c) => treeDepth(c, adjList)));
}

// ── Main handler ──────────────────────────────────────────────────────────────

app.post("/bfhl", (req, res) => {
  const data = req.body?.data;
  if (!Array.isArray(data)) {
    return res.status(400).json({ error: "data must be an array of strings" });
  }

  const invalidEntries = [];
  const duplicateEdges = [];
  const seenEdges = new Set();
  const validEdges = [];

  // ── Step 1: Validate & deduplicate ──────────────────────────────────────────
  for (const raw of data) {
    if (typeof raw !== "string") { invalidEntries.push(String(raw)); continue; }
    const trimmed = raw.trim();
    const parsed = parseEdge(trimmed);
    if (!parsed) { invalidEntries.push(trimmed); continue; }

    const key = `${parsed.parent}->${parsed.child}`;
    if (seenEdges.has(key)) {
      if (!duplicateEdges.includes(key)) duplicateEdges.push(key);
      continue;
    }
    seenEdges.add(key);
    validEdges.push(parsed);
  }

  // ── Step 2: Build adjacency list respecting multi-parent rule ───────────────
  const adjList = {};   // parent -> [children]
  const childParent = {}; // child -> first-seen parent

  for (const { parent, child } of validEdges) {
    if (child in childParent) continue; // already has a parent — discard
    childParent[child] = parent;
    if (!adjList[parent]) adjList[parent] = [];
    adjList[parent].push(child);
  }

  // Collect all nodes
  const allNodes = new Set();
  for (const { parent, child } of validEdges) {
    allNodes.add(parent);
    allNodes.add(child);
  }

  // ── Step 3: Find connected components ───────────────────────────────────────
  const find = buildUnionFind(validEdges);
  const components = {};
  for (const node of allNodes) {
    const root = find(node);
    if (!components[root]) components[root] = new Set();
    components[root].add(node);
  }

  // ── Step 4: For each component build hierarchy ──────────────────────────────
  const hierarchies = [];
  let totalTrees = 0;
  let totalCycles = 0;
  let largestRoot = null;
  let largestDepth = -1;

  for (const compNodes of Object.values(components)) {
    const nodeSet = [...compNodes];

    // Build sub-adjList for this component
    const subAdj = {};
    nodeSet.forEach((n) => { subAdj[n] = adjList[n] || []; });

    // Detect cycle
    const cycle = hasCycle(nodeSet, subAdj);

    // Find roots: nodes never appearing as a child
    const childSet = new Set(nodeSet.filter((n) => n in childParent));
    const roots = nodeSet.filter((n) => !childSet.has(n));

    let rootNode;
    if (roots.length > 0) {
      rootNode = roots.sort()[0];
    } else {
      // Pure cycle — pick lex smallest
      rootNode = nodeSet.sort()[0];
    }

    if (cycle) {
      totalCycles++;
      hierarchies.push({ root: rootNode, tree: {}, has_cycle: true });
    } else {
      totalTrees++;
      const innerTree = buildTree(rootNode, subAdj);
      const fullTree = { [rootNode]: innerTree };
      const depth = treeDepth(rootNode, subAdj);

      hierarchies.push({ root: rootNode, tree: fullTree, depth });

      if (
        depth > largestDepth ||
        (depth === largestDepth && rootNode < largestRoot)
      ) {
        largestDepth = depth;
        largestRoot = rootNode;
      }
    }
  }

  // Sort hierarchies by root for deterministic output
  hierarchies.sort((a, b) => a.root.localeCompare(b.root));

  res.json({
    user_id: USER_ID,
    email_id: EMAIL_ID,
    college_roll_number: ROLL,
    hierarchies,
    invalid_entries: invalidEntries,
    duplicate_edges: duplicateEdges,
    summary: {
      total_trees: totalTrees,
      total_cycles: totalCycles,
      largest_tree_root: largestRoot || "",
    },
  });
});

// Health check
app.get("/", (req, res) => res.json({ status: "ok", route: "POST /bfhl" }));

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`BFHL API running on port ${PORT}`));
